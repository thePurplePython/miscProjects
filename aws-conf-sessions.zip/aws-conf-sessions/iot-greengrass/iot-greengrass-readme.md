## OEE Workshop

[Here](http://workshop.industrial-architecture.cloud/oee/) you can find the instructions to run this workshop.

These accounts are being provided free of charge by AWS but will be removed as soon as the event is over. 

The workshop documentation and resources are public and you can continue experimenting with the workshop on your own account.
