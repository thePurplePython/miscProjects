# Deep learning with Apache MXNet - AIM403-R

<div style="text-align:center"><img src="https://pbs.twimg.com/media/DdR-mmGVAAAzGGA.jpg:large" height=200 style="text-align:center"></img></div>


## Step 1: Login in your provided AWS account

Use the credentials provided by the organizers to login your account

## Step 2: Create a notebook instance

1) Navigate to: Services > Amazon SageMaker > Notebook Instances

2) Click Create Notebook Instance

3) Choose any name and Pick **ml.p3.2xlarge** as your instance type

4) In addtional configuration, pick 100GB as your disk size

5) Leave everything the same except in **git repositories** add this URL as a public repository: https://gist.github.com/ThomasDelteil/5a02f2245ee574e16f7d62c7633fdbe7

6) Click create notebook instance

## Step 3: Sit back and relax

While the instance is getting launched we're going to give you a primer on SageMaker and the workshop objectives!

## Step 4: Login the jupyter notebook

Click: "Open Jupyter" and **DO NOT** click "Open Jupyterlab", we're using the old jupyter notebook to allow a cool demo at the end to run directly in the browser.

## Step 5: Open DiceDetection_SageMaker.ipynb

Follow the instructions from then on! Have fun and get building!